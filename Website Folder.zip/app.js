var scrollButton = document.getElementsByClassName("button")

// Function scrolls to bottom of the page 
function scrollToBottom(event) {
    event.preventDefault()
    window.scrollTo({
        top: document.body.scrollHeight,
        behavior: "smooth"
    })
}

for (let i = 0; i < Object.keys(scrollButton).length; i++) {
    scrollButton[i].addEventListener("click", scrollToBottom)
}